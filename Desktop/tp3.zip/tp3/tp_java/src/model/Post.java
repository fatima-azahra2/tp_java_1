package model;

public enum Post {
	DEVELOPER, DESIGNER, MARKETING, OTHER
}