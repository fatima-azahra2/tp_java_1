package model;

public enum Type_holiday {
	ANNUAL, SICK, MATERNITY, OTHER,
}